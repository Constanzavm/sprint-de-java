package interfaz;

/**
 * Interfaz encargada de analizar datos de "Usuario" solicitados por las distintas Clases de este Tipo.
 */

public interface IAsesoria {
    public String analizarUsuario();
}
